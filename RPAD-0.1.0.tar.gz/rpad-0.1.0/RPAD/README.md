!pip install RPAD-0.1.0.tar.gz

from google.colab import drive
drive.mount('/content/drive/')
!pip install 'drive/MyDrive/RPAD-0.1.0.tar.gz'

import RPAD

import RPAD as rp